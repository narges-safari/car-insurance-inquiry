// car action types
export const GET_CAR_TYPES = "GET_CAR_TYPES";
export const GET_CAR_THIRD_DISCOUNT = "GET_CAR_THIRD_DISCOUNT";

// insurance action types
export const GET_INSURANCE_COMPANY = "GET_INSURANCE_COMPANY";

// info form
export const SET_INFO_FORM = "SET_INFO_FORM";
