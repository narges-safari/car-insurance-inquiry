const PROTOCOL = "http";
const BASE = "bimename.com/bimename"; //window.location.hostname;

export { PROTOCOL, BASE };
